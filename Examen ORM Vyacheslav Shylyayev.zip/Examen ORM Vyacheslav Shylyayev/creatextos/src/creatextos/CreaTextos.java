/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package creatextos;

import org.hibernate.Session;
import org.hibernate.Transaction;
import ORM.*;

/**
 *
 * @author Vyacheslav Shylyayev
 */
public class CreaTextos {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
         
        try (Session s = HibernateUtil.getSessionFactory().openSession()){
            Transaction t = s.beginTransaction();
            try {
                Texto texto1 = new Texto(s.get(Idioma.class, "es"));
                texto1.setNumPalabras(100);
                Texto texto2 = new Texto(s.get(Idioma.class, "pt"));
                texto2.setNumPalabras(200);
                Texto texto3 = new Texto(s.get(Idioma.class, "it"));
                texto3.setNumPalabras(300);
                
                s.saveOrUpdate(texto1);                
                s.saveOrUpdate(texto2);
                s.saveOrUpdate(texto3);

                t.commit();
            } catch (Exception e){
                e.printStackTrace();
                t.rollback();
            }
        }
        
    }
    
}
