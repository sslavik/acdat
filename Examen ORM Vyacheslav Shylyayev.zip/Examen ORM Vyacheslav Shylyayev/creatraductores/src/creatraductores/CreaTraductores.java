/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package creatraductores;

import org.hibernate.Session;
import org.hibernate.Transaction;
import ORM.*;

/**
 *
 * @author Vyacheslav Shylyayev
 */
public class CreaTraductores {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        String[][] datosTraductores = {
            {"37515445G", "LÓPEZ", "es"},  
            {"X5353636P", "ROSSI", "it"},  
            {"73453363W", "SCHMIDT", "de"}
        };
         
        try (Session s = HibernateUtil.getSessionFactory().openSession()){
            Transaction t = s.beginTransaction();
            try {
                for (String[] item : datosTraductores) {
                    Traductor traductor = new Traductor(item[0], s.get(Idioma.class, item[2]), item[1]);
                    s.saveOrUpdate(traductor);
                }
                t.commit();
            } catch (Exception e){
                e.printStackTrace();
                t.rollback();
            }
        }
        
    }
    
}
