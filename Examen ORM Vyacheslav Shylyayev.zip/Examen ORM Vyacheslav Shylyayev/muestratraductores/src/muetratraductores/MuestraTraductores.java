/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package muetratraductores;

import org.hibernate.Session;
import org.hibernate.Transaction;
import ORM.*;
import java.util.List;
import java.util.Set;
import org.hibernate.Query;

/**
 *
 * @author Vyacheslav Shylyayev
 */
public class MuestraTraductores {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
         
        try (Session s = HibernateUtil.getSessionFactory().openSession()){
            Transaction t = s.beginTransaction();
            try {
                // Obtenemos los traductores ordenados
                Query q = s.createQuery("from Traductor order by nom_trad");
                // Los guardamos en la lista
                List resultado = q.getResultList();
                // Los listamos
                for (Object object : resultado) {
                    Traductor tmp = (Traductor)object;
                    System.out.print("Traductor Nombre : " + tmp.getNomTrad() + 
                            " | Idioma materno : " + tmp.getIdioma().getNomIdioma() +
                            " | Idioma Traducibles :" 
                    );
                    for (Object idioma : tmp.getIdiomas()) {
                        System.out.print( " " + ((Idioma)idioma).getNomIdioma());
                    }
                    System.out.println("");
                }
                
                t.commit();
            } catch (Exception e){
                e.printStackTrace();
                t.rollback();
            }
        }
        
    }
    
}
