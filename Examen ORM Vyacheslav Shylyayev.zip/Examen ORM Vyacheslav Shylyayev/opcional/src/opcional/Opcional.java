/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package opcional;

import org.hibernate.Session;
import org.hibernate.Transaction;
import ORM.*;
import java.util.List;
import java.util.Set;
import org.hibernate.Query;

/**
 *
 * @author Vyacheslav Shylyayev
 */
public class Opcional {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
         
        try (Session s = HibernateUtil.getSessionFactory().openSession()){
            Transaction t = s.beginTransaction();
            try {
                
                TraductorJurado tj = new TraductorJurado("1235451X", s.get(Idioma.class, "es"), "Nombre Ejemplo");
                
                s.saveOrUpdate(tj);
                
                t.commit();
            } catch (Exception e){
                e.printStackTrace();
                t.rollback();
            }
        }
        
    }
    
}
