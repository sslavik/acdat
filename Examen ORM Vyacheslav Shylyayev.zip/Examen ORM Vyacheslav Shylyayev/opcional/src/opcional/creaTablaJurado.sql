/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 * Author:  Vyacheslav Shylyayev
 * Created: 13 feb. 2020
 */

create table if not exists traductor_jurado (
    dni_nie_trad char(9) primary key,
    idioma char(2)
);

