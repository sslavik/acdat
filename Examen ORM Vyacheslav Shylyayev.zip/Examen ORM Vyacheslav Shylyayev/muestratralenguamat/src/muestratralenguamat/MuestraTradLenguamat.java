/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package muestratralenguamat;

import org.hibernate.Session;
import org.hibernate.Transaction;
import ORM.*;

/**
 *
 * @author Vyacheslav Shylyayev
 */
public class MuestraTradLenguamat {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
         
        try (Session s = HibernateUtil.getSessionFactory().openSession()){
            Transaction t = s.beginTransaction();
            try {
                if(args.length < 1){
                    System.out.println("ERROR : Necesito un idioma para buscar por lengua materna");
                    System.exit(0); // SALE CON ERROR IDOMA NO PASADO
                }
                
                Idioma i = s.get(Idioma.class, args[0]);
                
                if (i == null){
                    System.out.println("ERROR : No existe un idioma con el ID : " + args[0] + " pasado");
                }
                else {
                    for (Object traductor : i.getTraductors()) {
                        Traductor tmp = ((Traductor)traductor);
                        System.out.print("Traductor DNI : " + tmp.getDniNie() 
                                + " | Nombre : " + tmp.getNomTrad() 
                                + " | IDIOMA MATERNO : " + tmp.getIdioma().getNomIdioma());
                    }
                }
                

                t.commit();
            } catch (Exception e){
                e.printStackTrace();
                t.rollback();
            }
        }
        
    }
    
}
