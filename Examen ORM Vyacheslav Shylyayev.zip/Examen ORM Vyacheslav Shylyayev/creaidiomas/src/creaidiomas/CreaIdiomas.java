/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package creaidiomas;

import org.hibernate.Session;
import org.hibernate.Transaction;
import ORM.*;

/**
 *
 * @author Vyacheslav Shylyayev
 */
public class CreaIdiomas {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
         
        try (Session s = HibernateUtil.getSessionFactory().openSession()){
            Transaction t = s.beginTransaction();
            try {
                Idioma i = new Idioma("en", "ENGLISH");
                Idioma i2 = new Idioma("es", "ESPAÑOL");
                Idioma i3 = new Idioma("de", "DEUTSCH");
                Idioma i4 = new Idioma("it", "ITALIANO");
                Idioma i5 = new Idioma("fr", "FRANCÉS");
                Idioma i6 = new Idioma("pt", "PORTUGUÉS");
                s.saveOrUpdate(i);
                s.saveOrUpdate(i2);
                s.saveOrUpdate(i3);
                s.saveOrUpdate(i4);
                s.saveOrUpdate(i5);
                s.saveOrUpdate(i6);
                t.commit();
            } catch (Exception e){
                e.printStackTrace();
                t.rollback();
            }
        }
        
    }
    
}
