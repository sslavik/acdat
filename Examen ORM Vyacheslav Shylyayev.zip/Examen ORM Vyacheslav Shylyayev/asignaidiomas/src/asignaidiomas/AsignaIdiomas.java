/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package asignaidiomas;

import org.hibernate.Session;
import org.hibernate.Transaction;
import ORM.*;
import java.util.Set;

/**
 *
 * @author Vyacheslav Shylyayev
 */
public class AsignaIdiomas {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
         
        try (Session s = HibernateUtil.getSessionFactory().openSession()){
            Transaction t = s.beginTransaction();
            try {
                
                Traductor traductor = s.get(Traductor.class, "37515445G");
                // AÑADIMOS IDIOMAS A TRADUCTOR_LENGUA
                traductor.setIdiomas(Set.of(
                        s.get(Idioma.class, "de"), 
                        s.get(Idioma.class, "it")
                ));
                s.saveOrUpdate(traductor);
                
                t.commit();
            } catch (Exception e){
                e.printStackTrace();
                t.rollback();
            }
        }
        
    }
    
}
