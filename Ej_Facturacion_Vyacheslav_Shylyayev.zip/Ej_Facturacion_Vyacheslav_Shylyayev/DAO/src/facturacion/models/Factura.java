/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package facturacion.models;

import java.sql.*;
        
/**
 *
 * @author usuario
 */
public class Factura {
    
    private int num_factura;
    private int id_cliente;
    private Date fecha_factura;
    
    // CONSTRUCTOR

    public Factura(int id_cliente, Date fecha_factura) {
        this.id_cliente = id_cliente;
        this.fecha_factura = fecha_factura;
    }
    

    public int getNum_factura() {
        return num_factura;
    }

    public void setNum_factura(int num_factura) {
        this.num_factura = num_factura;
    }

    public int getId_cliente() {
        return id_cliente;
    }

    public void setId_cliente(int id_cliente) {
        this.id_cliente = id_cliente;
    }

    public Date getFecha_factura() {
        return fecha_factura;
    }

    public void setFecha_factura(Date fecha_factura) {
        this.fecha_factura = fecha_factura;
    }
    
    
}
