/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package xpathinfoprovincias;

import java.io.PrintStream;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpression;
import javax.xml.xpath.XPathFactory;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.XMLReader;
import org.xml.sax.helpers.DefaultHandler;
import org.xml.sax.helpers.XMLReaderFactory;

/**
 *
 * @author Vyacheslav Shylyayev
 */
public class XPathInfoProvincias {

     // CAMPOS ESTATICOS
    public static final String xmlDocFilePath = "provinciasypoblaciones.xml";
    public static final String nodoBuscado = "provincia";
    public static String codigoBuscado = "";
    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        //File fileXML = new File(xmlDocFilePath);
        if(args.length != 1){
            System.out.println("ERROR. Se debe pasar 1 argumento por línea de comandos del código de provincia");
            System.exit(0);
        }
        if(args.length == 1){
            codigoBuscado = args[0];
        }
        try {
            
            Document docXML = DocumentBuilderFactory.newInstance().newDocumentBuilder().parse(xmlDocFilePath);
            XPathExpression expression = XPathFactory.newInstance().newXPath().compile("//"+nodoBuscado+"[@id='"+codigoBuscado+"']");
            
            System.out.println("Codigo de provincia : " + codigoBuscado);
            
            // GUARDAMOS EL RESULTADO DEL XPATHEVALUATE EN UN NodeList
            NodeList nodeList = (NodeList) expression.evaluate(docXML, XPathConstants.NODESET);
            
            if(nodeList.getLength() < 1){
                System.out.println("NO EXISTE NINGUNA PROVINCIA COINCIDENTE");
            }
            
            else {
                for (int i = 0; i < nodeList.getLength(); i++) {
                    NodeList datosProvincia = nodeList.item(i).getChildNodes();
                    for (int j = 0; j < datosProvincia.getLength(); j++) {
                        if(datosProvincia.item(j).getNodeName().equals("nombre")){
                            System.out.println("Nombre provincia : " + datosProvincia.item(j).getTextContent());
                        }
                        if(datosProvincia.item(j).getNodeName().equals("localidades")){
                            for (int k = 0; k < datosProvincia.item(j).getChildNodes().getLength(); k++) {
                                if(datosProvincia.item(j).getChildNodes().item(k).getNodeName().equals("localidad")){
                                    System.out.println(" - " + datosProvincia.item(j).getChildNodes().item(k).getTextContent());
                                }
                            }
                        }
                    }
                }
                
            }
                        
        } catch (Exception e) {
            e.printStackTrace();
        }
        
    }
    
}
