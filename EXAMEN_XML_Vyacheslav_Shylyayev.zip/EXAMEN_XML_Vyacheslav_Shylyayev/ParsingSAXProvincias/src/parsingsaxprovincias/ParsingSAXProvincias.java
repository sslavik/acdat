/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package parsingsaxprovincias;

import java.io.PrintStream;
import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.XMLReader;
import org.xml.sax.helpers.DefaultHandler;
import org.xml.sax.helpers.XMLReaderFactory;

/**
 *
 * @author Vyacheslav Shylyayev
 */
public class ParsingSAXProvincias {

     // CAMPOS ESTATICOS
    public static final String xmlDocFilePath = "provinciasypoblaciones.xml";
    public static final String nodoProvincia = "provincia";
    public static String codigoProvincia = "";
    public static String nombreProvincia = "";
    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        //File fileXML = new File(xmlDocFilePath);
        if(args.length != 1){
            System.out.println("ERROR. Se debe pasar 1 argumento por línea de comandos con el código de provincia");
            System.exit(0);
        }
        if(args.length == 1){
            codigoProvincia = args[0];
        }
        try {
            
            XMLReader parserSAX = XMLReaderFactory.createXMLReader(); // SE CREA UN XMLReader EL CUAL SERÁ NUESTRO LECTOR Con el Método Estatico XMLReaderFactorycreateXMLReader()
            // ESTE ULTIMO ES EQUIVALENTE AL DocumentBuilderFactory. Gestiona la configuración de la lectura del XML
            GestorEventos gestorEventos = new GestorEventos(System.out); // LA CLASE QUE GESTIONARÁ EL CONTENIDO PASADO
            parserSAX.setContentHandler(gestorEventos); // EL LECTOR O PARSERSAX LE DECIMOS CUAL ES EL GESTOR UTILIZADO
            parserSAX.parse(xmlDocFilePath); // LE PASAMO EL CONTENIDO QUE TIENE QUE PARSEAR MEDIANTE UNA RUTA ABSOLUTA
            
                        
        } catch ( SAXException e) {
            System.err.println(e.getMessage());
        } catch (Exception e) {
            e.printStackTrace();
        }
        
    }

    private static class GestorEventos extends DefaultHandler{

        // CAMPOS
        PrintStream ps;
        boolean provinciaEncontrada = false;
        boolean leerNombreProvincia = false;
        boolean leerLocalidad = false;
        
        public GestorEventos(PrintStream printStream) {
            ps = printStream;
        }
        
        
        /**
         * Este método es llamado con el PrintStream pasado ( Que es todo el contenido XML ) para recorrerlo y gestionarlo con todos los parametros encontrados.
         * @param uri 
         * @param localName Nombre de cada elemento
         * @param qName Nombre cualificativo de cada elemento
         * @param attributes Todos los atributos encontrados en cada Elemento
         * @throws SAXException  Excepción en caso de que no tenga el formato correcto
         */
        @Override
        public void startElement(String uri, String localName, String qName, Attributes attributes) throws SAXException {
            
            // RECORREMOS EL DOM Y BUSCAMOS POR el  LocalName o QualificativeName QUE SEA IGUAL AL QUE BUSCAMOS
            if(localName.equals(nodoProvincia) && attributes.getValue("id").equals(codigoProvincia)){
                if(attributes.getValue("id").endsWith(codigoProvincia)){
                    provinciaEncontrada = true;
                }
            }
            if(provinciaEncontrada && localName.equals("nombre")){
                leerNombreProvincia = true;
            }
            if(provinciaEncontrada && localName.equals("localidad")){
                leerLocalidad = true;
            }
            if(localName.equals(nodoProvincia) && !attributes.getValue("id").equals(codigoProvincia))
                provinciaEncontrada = false;
                        
        }

        @Override
        public void characters(char[] ch, int start, int length) throws SAXException {
            if(leerNombreProvincia){
                ps.println("Código de provincia : " + codigoProvincia);
                ps.println("Nombre de provincia : " + new String(ch, start, length).trim() + "\n");
                leerNombreProvincia = false;
            }
            if(leerLocalidad && provinciaEncontrada){
                ps.println(" - " + new String(ch, start, length).trim());
                leerLocalidad = false;
            }
        }
        
        
        
        
        
        
        
    }
    
}
