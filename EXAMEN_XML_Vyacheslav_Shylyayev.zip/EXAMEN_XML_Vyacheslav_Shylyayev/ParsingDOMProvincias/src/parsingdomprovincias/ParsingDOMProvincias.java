/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package parsingdomprovincias;

import java.io.PrintStream;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpression;
import javax.xml.xpath.XPathFactory;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.XMLReader;
import org.xml.sax.helpers.DefaultHandler;
import org.xml.sax.helpers.XMLReaderFactory;

/**
 *
 * @author Vyacheslav Shylyayev
 */
public class ParsingDOMProvincias {

     // CAMPOS ESTATICOS
    public static final String xmlDocFilePath = "provinciasypoblaciones.xml";
    public static final String nodoBuscado = "localidad";
    public static String cadenaBuscada = "";
    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        //File fileXML = new File(xmlDocFilePath);
        if(args.length != 1){
            System.out.println("ERROR. Se debe pasar 1 argumento por línea de comandos con una línea de caracteres");
            System.exit(0);
        }
        if(args.length == 1){
            cadenaBuscada = args[0];
        }
        try {
            
            Document docXML = DocumentBuilderFactory.newInstance().newDocumentBuilder().parse(xmlDocFilePath);
            XPathExpression expression = XPathFactory.newInstance().newXPath().compile("//"+nodoBuscado);
            
            System.out.println("Buscando Localidades cuyo nombre contiene : " + cadenaBuscada);
            
            System.out.println("RESULTADO : ");
            int contador = 0;
            
            // GUARDAMOS EL RESULTADO DEL XPATHEVALUATE EN UN NodeList
            NodeList nodeList = (NodeList) expression.evaluate(docXML, XPathConstants.NODESET);
            
            if(nodeList.getLength() < 1){
                System.out.println("NO EXISTE NINGUNA NODO COINCIDENTE");
            }
            else {
                for (int i = 0; i < nodeList.getLength(); i++) {
                    if( nodeList.item(i).getNodeType() == Node.ELEMENT_NODE &&
                        nodeList.item(i).getTextContent().toLowerCase().contains(cadenaBuscada.toLowerCase())){
                        // OBTENEMOS LA COINCIDENCIA
                        System.out.print(nodeList.item(i).getTextContent());
                        // PINTAMOS LA PROVINCIA
                        System.out.println(" [" +nodeList.item(i).getParentNode().getParentNode().getAttributes().getNamedItem("id").getTextContent() + "]");
                        contador++;
                    }
                }
                if (contador == 0)
                    System.out.println("NO HAY COINCIDENCIAS");
            }
                        
        } catch (Exception e) {
            e.printStackTrace();
        }
        
    }
    
}
