/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package creaasigtraductores;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;

/**
 *
 * @author usuario
 */
public class CreaAsigTraductores {

    static final String BASEDATOS = "traducciones";
    static final String HOST = "localhost";
    static final String PORT = "3306";
    static final String PAR_ADIC = "?useUnicode=true&useJDBCCompliantTimezoneShift=true&useLegacyDatetimeCode=false&serverTimezone=UTC&useSSL=false";
    static final String CONNECTION_URL = "jdbc:mysql://" + HOST + ":" + PORT + "/" + BASEDATOS + PAR_ADIC;
    static final String USER = "traducciones";
    static final String PWD = "traducciones";
    static Connection con = null;

    static final String NOM_TABLA = "idioma";
    static final int NUM_CAMPOS = 3;

    private static void muestraErrorSQL(SQLException e) {
        System.err.println("SQL ERROR mensaje: " + e.getMessage());
        System.err.println("SQL Estado: " + e.getSQLState());
        System.err.println("SQL código específico: " + e.getErrorCode());
    }

    /**
     * Solo se usa una conexión, que es una variable estática de clase, y se
     * crea la primera vez que se llama a este método.
     *
     * @return Conexión
     * @throws SQLException
     */
    private static Connection obtenConexion() throws SQLException {
        if (con == null) {
            con = DriverManager.getConnection(CONNECTION_URL, USER, PWD);
        }
        return con;
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        try {
        Connection c = obtenConexion();
        
        Texto t = new Texto();
        t.setNum_palabras(58634);
        t.setCod_idioma("es");
        int codTexto = t.save(c); // Abierto previamente
            System.out.println(" CODIGO OBTENIDO DE INSERCION : " + codTexto );
            
        Texto t1 = new Texto(codTexto, c);
        
        System.out.print("Texto " + t1.getId_texto() + ", " + t1.getNum_palabras() + " palabras en "+ t1.getCod_idioma() +" \n");
        
        
        ArrayList<HashMap<String, String>> lTrad = new ArrayList<HashMap<String,String>>();
        
        HashMap asig = new HashMap();
        asig.put("cod_idioma_dest", "it");
        asig.put("dni_niew_trad", "X565434");
        HashMap asig2 = new HashMap();
        asig.put("cod_idioma_dest", "de");
        asig.put("dni_niew_trad", "X95342A");
        lTrad.add(asig);
        lTrad.add(asig2);
        t.asignaTraductores(lTrad, c);
        
        
        
        } catch (Exception e){
            e.printStackTrace();
        } 
    }
    
}
