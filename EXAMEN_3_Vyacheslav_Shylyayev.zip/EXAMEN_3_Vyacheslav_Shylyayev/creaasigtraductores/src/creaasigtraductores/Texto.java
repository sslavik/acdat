/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package creaasigtraductores;

import java.sql.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

/**
 *
 * @author Vyacheslav Shylyayev
 */
public class Texto {
    
    // CAMPOS 
    int id_texto;
    int num_palabras;
    String cod_idioma;
    
    // CONSTRUCTOR

    public Texto() {
    }
    
    // CON ESTE OBTENEMOS UNA FILA CREADA EN LA BASE DE DATOS
    public Texto(int id_texto, Connection c) throws SQLException{
        
        String statement = "SELECT * FROM texto;";
        
        try (PreparedStatement ps = c.prepareStatement(statement)){
            
            ResultSet rs = ps.executeQuery();
            
            while(rs.next()){
                
                int i = 1;

                setNum_palabras(rs.getInt(++i));
                setCod_idioma(rs.getString(++i));
            }
        } 
        
    }
    
    // METODOS
    
    public int save(Connection c) throws SQLException{
        
        String statement = "INSERT INTO texto(num_palabras,cod_idioma) VALUES(?,?) ON DUPLICATE KEY UPDATE num_palabras=?,cod_idioma=?;";
        
        try (PreparedStatement ps = c.prepareStatement(statement, Statement.RETURN_GENERATED_KEYS)){
            
            int i = 0;
            
            ps.setInt(++i, getNum_palabras());
            ps.setString(++i, getCod_idioma());
            ps.setInt(++i, getNum_palabras());
            ps.setString(++i, getCod_idioma());
            
            ps.executeUpdate();

            // DEVUELVE EL AUTO_INCREMENT
            ResultSet rs = ps.getGeneratedKeys();
            
            rs.next();
            
            return rs.getInt(1); // OBTENEMSO EL PRIMERO QUE ES EL DE id_texto
        } 
        
    }
    
    public boolean asignaTraductores(List<HashMap<String,String>> lTrad, Connection c) throws SQLException{
        
        String statement = "INSERT INTO asig_traduccion(id_texto,cod_idioma_dest,dni_niew_trad,) VALUES(?,?,?) ON DUPLICATE KEY UPDATE id_texto=?, cod_idioma_dest=?, dni_niew_trad=?;";
        
        try (PreparedStatement ps = c.prepareStatement(statement)){
            
            int i = 0;
            for(HashMap<String, String> h : lTrad){
                ps.setInt(++i, getId_texto());
                ps.setString(++i, h.get("cod_idioma_dest").toString());
                ps.setString(++i, h.get("dni_niew_trad").toString());
                ps.setInt(++i, getId_texto());
                ps.setString(++i, h.get("cod_idioma_dest").toString());
                ps.setString(++i, h.get("dni_niew_trad").toString());
                 
                ps.executeUpdate();
            }
            
           

        } 
        
        return true;
    }
    
    // PROPIEDADES

    public int getId_texto() {
        return id_texto;
    }
    
    public int getNum_palabras() {
        return num_palabras;
    }

    public void setNum_palabras(int num_palabras) {
        this.num_palabras = num_palabras;
    }

    public String getCod_idioma() {
        return cod_idioma;
    }

    public void setCod_idioma(String cod_idioma) {
        this.cod_idioma = cod_idioma;
    }

    
}
